function inspectGooglePage() {
  const params = new URLSearchParams(location.search);
  const query = params.get("q") || document.title || "Google Search";

  // Google does not provide a stable public DOM flag for Knowledge Panels.
  // These selectors are heuristics and can change as Google changes its layout.
  const candidateSelectors = [
    '[data-attrid="kc:/people/person:"]',
    '[data-attrid^="kc:"]',
    '[data-attrid^="kc:/"]',
    '[role="complementary"]',
    '[data-ved] [data-attrid]'
  ];

  let candidate = false;
  for (const selector of candidateSelectors) {
    const nodes = document.querySelectorAll(selector);
    for (const node of nodes) {
      const rect = node.getBoundingClientRect();
      const text = (node.innerText || "").trim();
      if (rect.width > 180 && rect.height > 100 && text.length > 80) {
        candidate = true;
        break;
      }
    }
    if (candidate) break;
  }

  // Secondary heuristic: a substantial right-side result block with entity-like
  // information. This is deliberately reported as "possible", never verified.
  const main = document.querySelector("#rhs") || document.querySelector('[role="complementary"]');
  const rhsText = main ? (main.innerText || "").trim() : "";
  const rightSideCandidate = !!(main && rhsText.length > 120 && main.getBoundingClientRect().width > 180);

  return {
    query,
    panelLikely: candidate || rightSideCandidate,
    panelUnclear: !candidate && !rightSideCandidate && !!document.querySelector("#rhs")
  };
}

chrome.runtime.onMessage.addListener((message, sender, sendResponse) => {
  if (message && message.type === "ANALYZE_GOOGLE_RESULTS") {
    sendResponse(inspectGooglePage());
  }
});
