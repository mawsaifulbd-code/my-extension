const $ = (id) => document.getElementById(id);

function setResult(status, title, description, tone = "neutral") {
  $("statusPill").textContent = status;
  $("statusPill").className = `pill ${tone}`;
  $("resultTitle").textContent = title;
  $("resultText").textContent = description;
}

async function getActiveTab() {
  const [tab] = await chrome.tabs.query({active: true, currentWindow: true});
  return tab;
}

$("searchBtn").addEventListener("click", () => {
  const name = $("personName").value.trim();
  if (!name) {
    $("pageStatus").textContent = "Enter a person's name first.";
    return;
  }
  const url = "https://www.google.com/search?q=" + encodeURIComponent(name);
  chrome.tabs.create({url});
});

$("analyzeBtn").addEventListener("click", async () => {
  $("pageStatus").textContent = "Checking the current page…";
  try {
    const tab = await getActiveTab();
    if (!tab || !tab.url || !/google\.[^/]+\/search/.test(tab.url)) {
      setResult("Google page needed", "Open Google Search first", "Go to Google and search for a person's name. Then reopen this extension.");
      $("pageStatus").textContent = "Current tab is not a supported Google Search results page.";
      return;
    }
    const response = await chrome.tabs.sendMessage(tab.id, {type: "ANALYZE_GOOGLE_RESULTS"});
    if (!response) throw new Error("No response from the page.");
    const query = response.query || "Current search";
    if (response.panelLikely) {
      setResult("Possible panel found", query, "A possible Knowledge Panel-style information area was detected. Review the Google page manually to confirm it belongs to the correct person.", "good");
    } else if (response.panelUnclear) {
      setResult("Needs manual review", query, "The page structure was not clear enough to determine whether a Knowledge Panel is present.", "warn");
    } else {
      setResult("Not detected", query, "No likely Knowledge Panel area was detected by this preliminary check. This does not prove that Google has no Knowledge Panel for this person.", "warn");
    }
    $("pageStatus").textContent = "Analysis completed on the current search page.";
  } catch (error) {
    setResult("Could not analyze", "Refresh Google Search", "Refresh the Google results page and try again. Some Google page layouts may not expose the required information.");
    $("pageStatus").textContent = error.message || "Could not connect to the Google page.";
  }
});

document.querySelectorAll("[data-search]").forEach(button => {
  button.addEventListener("click", async () => {
    const term = button.dataset.search;
    const name = $("personName").value.trim();
    if (!name) {
      $("pageStatus").textContent = "Enter a person's name first, then choose a research shortcut.";
      return;
    }
    const q = term === "website" ? `"${name}" official website` :
      term === "email" ? `"${name}" email contact` :
      `"${name}" ${term}`;
    chrome.tabs.create({url: "https://www.google.com/search?q=" + encodeURIComponent(q)});
  });
});
